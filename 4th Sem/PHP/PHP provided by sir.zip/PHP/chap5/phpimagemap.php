<html>
<head>
<title>Reading data from image maps</title>
</head>
<body>
<h1>Reading data from image maps</h1>
You clicked the image map at
<?php
echo $_REQUEST["imap_x"], "  , " ,$_REQUEST["imap_y"];
?>
</body>
</html>