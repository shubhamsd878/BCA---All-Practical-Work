<html>
<head>
<title>Reading data from text fields</title>
</head>
<body>
<h1>
Reading text from text fields
</h1>
Thanks for Answering,
<?php
echo $_REQUEST["data"];
?>
</body>
</html>
