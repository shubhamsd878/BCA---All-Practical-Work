<html>
<head>
<title>
Reading Data from password Controls</title>
</head>
<body>
<h1>
Reading Data from password Controls
</h1>
<?php
echo $_REQUEST["customer_type"]
?>
  customer.
</body>
</html>

