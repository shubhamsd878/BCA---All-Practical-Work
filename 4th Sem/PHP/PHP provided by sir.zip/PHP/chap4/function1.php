<html>
<head>
<title>
Creating Functions
</title>
</head>
<body>
<h1>Creating Functions</h1>
<?php
echo  "About to call the Function......<br>";
echo "calling the Function.......<br>";
display();
function display()
{
echo "This text was display by the function.";

}

?>
</body>
</html>