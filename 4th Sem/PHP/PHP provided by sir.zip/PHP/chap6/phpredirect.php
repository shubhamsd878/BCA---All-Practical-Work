<html>
<head>
<title>
</title>
</head>
<body>
<?php
$redirect="Location: ".$_REQUEST['button'].".html";
echo header($redirect);

?>
</body>
</html>