<html>
<head>
<title>
</title>
</head>
<body>
<h1>Client-side data validation</h1>
<?php
echo $_REQUEST["date"];
?>
</body>
</html>
