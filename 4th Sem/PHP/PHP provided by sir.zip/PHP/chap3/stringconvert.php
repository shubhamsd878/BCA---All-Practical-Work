<html>
<head>
<title>
Converting from strings and numbers
</title>
</head>
<body>
<h1>Converting from strings and numbers</h1>
<?Php
$float=3.1415;
echo (string)$float,"<br>";
echo strval($float),"<br>";
$value=1+"19.2";
echo "$value <br>";
$text="3.0";
$value=(float) $text;
echo $value  /2.0,"<br>";


?>
</body>
</html>