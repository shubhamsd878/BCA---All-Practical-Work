<html>
<head>
<title>Using Impode & Expode to convert from Array to String</title>
</head>
<body>
<h1>Using Impode & Expode to convert from Array to String</h1>
<?php
$ice[0]="choclate";
$ice[1]="chocobar";
$ice[2]="Amul choco";
$ice[3]="cadbury choclate";

$text= impode(, , ,$ice);
echo $text;
?>
</body>
<html>