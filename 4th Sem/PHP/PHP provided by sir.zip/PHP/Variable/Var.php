<html>
<head><title>PHP Programs</title></head>
<body>
<?php
$x=4;
$y=4.2;

print $x===$y;



?>
</body>
</html>