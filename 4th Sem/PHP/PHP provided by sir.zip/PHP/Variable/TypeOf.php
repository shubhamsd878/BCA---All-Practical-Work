<html>
<head<<title>PHP Programs</title></head>
<body>
<?php
$a=10;
print "<br>";
print getType($a);
$a=10.99;
print "<br>";
print getType($a);
$a="Hello";
print "<br>";
print getType($a);
$a='a';
print "<br>";
print getType($a);
$a=true;
print "<br>";
print getType($a);
?>
</body>
</html>