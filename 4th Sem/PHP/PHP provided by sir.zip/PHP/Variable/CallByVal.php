<html>
<head<<title>PHP Programs</title></head>
<body>
<?php
$a=10;
print "<br>";
print $a;
$b=$a;
print "<br>";
print $b;
$a=20;
print "<br>";
print $a;
print "<br>";
print $b;



?>
</body>
</html>