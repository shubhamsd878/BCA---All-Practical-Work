<html>
<head>
<title>
Using the math operations</title>
</head>
<body>
<h1> Using the Math Operations</h1>
<?php
echo "7+3 = ",7+3, "<br>";
echo "7-2  = ",7-2,"<br>";
echo "7*2 =  ",7*2,"<br>";
echo "7/2 = ",7/2,"<br>";
echo "7%2 =",7%2,"<br>";
echo "pow(4,3) = ",pow(4,3),"<br>";
echo "floor(3.14159) = ",floor(3.14159),"<br>";
echo "tan(deg2rad(45)) = ",tan(deg2rad(45)),"<br>";
echo "sin(deg2rad(45)) = ",sin(deg2rad(45)),"<br>";
echo "dechex(16) = ",dechex(16),"<br>";
?>
</body>
</html>