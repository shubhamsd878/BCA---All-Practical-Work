<html>
<head>
<title>
Using the Logical  " OR " Operator</title>
</head>
<body>
<h1>Using the Logical  " OR " Operator</h1>
<?php
$temperature=66;
if($temperature <32 ||$temperature>100)
{
echo "Better stay inside today";
}
else
{
echo "Nice Stay Outside";
}
?>
</body>
</html>