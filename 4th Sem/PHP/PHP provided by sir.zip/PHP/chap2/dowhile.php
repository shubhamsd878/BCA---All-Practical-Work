<html>
<head>
<title>
Using Do While Loop
</title>
</head>
<body>
<h1>Using Do While Loop</h1>
<?php
$var=0;
do
{
echo "Now \$var holds:",$var,"<br>";
$var++;
}
while($var<10)
?>
</body>
</html>