<html>
<head>
<title>
Using Logical Operator</title>
</head>
<body>
<h1>Using the Logical Opearator</h1>
<?php
$temperature=66;
if($temperature>65 && $temperature<75)
{
echo "It's between 65 && 75 outside.";
}
?>
</body>
</html>