<html>
<head>
<title>
Using While Loop
</title>
</head>
<body>
<h1>Using While Loop</h1>
<?php
$var=1;
while($var<10)
{
echo "Now \$var holds:",$var,"<br>";
$var++;
}
?>
</body>
<html>
