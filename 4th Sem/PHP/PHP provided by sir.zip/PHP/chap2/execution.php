<html>
<head>
<title>
The Execution Operator
</title>
</head>
<body>
<?php
$output=`date`;
echo $output;
?>
</body>
</html>



