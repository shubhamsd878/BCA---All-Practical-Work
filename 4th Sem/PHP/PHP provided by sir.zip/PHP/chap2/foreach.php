<html>
<head>
<title>
Using For Each Loop
</title>
</head>
<body>
<h1>Using For Each Loop</h1>
<?php
$arr=array("turkey","ham","beef","hello","how");
foreach($arr as $value)
{
echo "Current sandwitch: $value<br>";
}
?>
</body>
</html>