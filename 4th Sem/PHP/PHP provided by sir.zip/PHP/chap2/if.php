<html>
<head>
<title>
If Statements</title>
</head>
<body>
<h1>EXECUTE THE  IF STATEMENTS</h1>
<?php
$minutes=31;
if($minutes>30)
{
echo "<b><marquee>Your time is UP</marquee><br>";
echo "Please get out of the pool"; 
}
?>
</body>
</html>