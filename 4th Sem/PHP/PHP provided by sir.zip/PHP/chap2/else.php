<html>
<head>
<title>Using the ElseIf Statement</title>
</head>
<body>
<h1>Using the ElseIf Statement</h1>
<?php
$gallons=5;
if($gallons<4)
{
echo "Got a Parachute?";
}
else
{
echo "You will be Ok";

}
?>
</body>
</html>