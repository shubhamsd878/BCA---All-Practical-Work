<html>
<head>
<title>
Using the comparison Operator</title>
</head>
<body>
<h1>Using the == Operator</h1>
<?php
$minutes=30;
if($minutes==30)
{
echo "Warning: <br>";
echo "Your time is yhr pool is almost up";
}
?>
</body>
</html>