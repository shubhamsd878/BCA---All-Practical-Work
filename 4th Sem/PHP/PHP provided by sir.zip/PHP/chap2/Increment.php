<html>
<head>
<title>
Incrementing & Decrementing PHP
</title>
</head>
<body>
<h1>Incrementing & Decrementing</h1>
<?php
$a=$b=$c=$d=1;
echo "\$a = \$b  =  \$c   = \$d=1 <br>";
echo "\$a++   gives   :   "   , $a++,"<br>";
echo "Now \$a  = ",$a,"<br>";
echo "++\$b gives ",  ++$b,"<br>";
echo  "\$c-- gives  ",$c--,"<br>";
echo " Now \$c =  ",$c ,"<br>";
echo "--\$d gives ", --$d,"<br>";

?>
</body>
</html>