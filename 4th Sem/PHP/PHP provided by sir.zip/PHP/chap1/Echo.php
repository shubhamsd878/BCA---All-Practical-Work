<html>
<head>
<title>
How to display text in PHP</title>
</head>
<body>
<h1>Here's what PHP has to say:
<br>
<br>
<?php 
echo "Welcome to PHP WORLD";
echo "PHP is the Open Source you can easily download from the Internet ";

echo 1234567890;
echo ("Hello PHP");

?>
</body>
<html>

