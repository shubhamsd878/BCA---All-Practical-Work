<html>
<head>
<title>
How to declare PHP varible</title>
</head>
<body>
<?php
$paris=2;
$london=5;
$boise=8;
echo "here is the answer  : ",$paris + $london + $boise , ".";

?>
</body>
</html>