<html>
<head>
<title>Dynamic Varible</title>
</head>
<body>
<h1> Storing Data in Varibles</h1>
<?php 
echo "Setting the number of cheeseburgers to 1.<br>";
echo "Current number of cheeseburgers : " ,$cheeseburgers, "<br>";
echo "Adding 3 more cheeseburgers.<br>";
$cheeseburgers=$cheeseburgers +3;
echo " Number of cheeseburgers now:  ", $cheeseburgers,"<br>";
?>
</body>
</html>