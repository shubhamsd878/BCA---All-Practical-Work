<code><span style="color: #000000">
&lt;code&gt;&lt;span&nbsp;style="color:&nbsp;#000000"&gt;<br />&amp;lt;code&amp;gt;&amp;lt;s</span>
</code>