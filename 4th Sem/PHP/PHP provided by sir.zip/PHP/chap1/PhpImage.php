<html>
<head>
<title>
How to use Image in PHP
</title>
</head>
<body>
<h1>
Using PHP & HTML Together
</h1>

<br>
<br>
<?php phpinfo();
?>
<img src="php-med-trans-light-gif">
</body>
</html>
