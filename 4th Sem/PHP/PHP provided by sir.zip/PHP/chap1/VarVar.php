<html>
<head>
<title>Defining Constants</title>
</head>
<body>
<h1>Defining Constants</h1>

<?php
define("PI", 3.1415926535,True);
echo "The value of pi is :--->", Pi ,"<br>";
?>
</body>
</html>