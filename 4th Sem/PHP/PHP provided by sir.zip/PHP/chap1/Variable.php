<html>
<head>
<title>PHP variable</title>
</head>
<body>
<?php
echo "Here is the Answer:  ----->" ,  1+3+8  , ".";
?>
</body>
</html>