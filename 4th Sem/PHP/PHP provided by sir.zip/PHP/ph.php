<html>
<head>
<title>
Using PHP and HTML togateher</title>
</head>
<body>
</h1>Using Php and Html togather</h1>
Here is ur Php Code:
<br>
<?php 
phpinfo();
?>
</body>
</html>


